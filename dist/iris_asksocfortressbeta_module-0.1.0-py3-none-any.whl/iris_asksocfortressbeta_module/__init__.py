#!/usr/bin/env python3
#
#
#  IRIS asksocfortressbeta Source Code
#  Copyright (C) 2023 - socfortress
#  info@socfortress.co
#  Created by socfortress - 2023-02-14
#
#  License MIT

__iris_module_interface = "IrisAsksocfortressbetaInterface"