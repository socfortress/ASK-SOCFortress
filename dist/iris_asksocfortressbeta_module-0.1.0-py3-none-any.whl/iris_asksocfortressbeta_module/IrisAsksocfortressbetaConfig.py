#!/usr/bin/env python3
#
#
#  IRIS asksocfortressbeta Source Code
#  Copyright (C) 2023 - socfortress
#  info@socfortress.co
#  Created by socfortress - 2023-02-14
#
#  License MIT

module_name = "ASK SOCFortress Beta"
module_description = "Ask SOCFortress how to respond to an IoC"
interface_version = 1.1
module_version = 1.0

pipeline_support = False
pipeline_info = {}


module_configuration = [
    {
        "param_name": "knowledgebase_url",
        "param_human_name": "Knowledge Base URL",
        "param_description": "Endpoint for Knowledge Base",
        "default": "https://api.socfortress.co/prompt",
        "mandatory": True,
        "type": "string"
    },
    {
        "param_name": "api_key",
        "param_human_name": "API KEY",
        "param_description": "API Key provided by SOCFortress.",
        "default": "xxxx",
        "mandatory": True,
        "type": "sensitive_string"
    },
    {
        "param_name": "firewall",
        "param_human_name": "Firewall Model",
        "param_description": "Your deployed firewall. I.E: Cisco, Palo Alto, pfSense, etc.",
        "default": "Cisco",
        "mandatory": True,
        "type": "string"
    },
    {
        "param_name": "asksocfortressbeta_manual_hook_enabled",
        "param_human_name": "Manual triggers on IOCs",
        "param_description": "Set to True to offers possibility to manually triggers the module via the UI",
        "default": True,
        "mandatory": True,
        "type": "bool",
        "section": "Triggers"
    },
    {
        "param_name": "asksocfortressbeta_on_create_hook_enabled",
        "param_human_name": "Triggers automatically on IOC create",
        "param_description": "Set to True to automatically add a asksocfortressbeta insight each time an IOC is created",
        "default": False,
        "mandatory": True,
        "type": "bool",
        "section": "Triggers"
    },
    {
        "param_name": "asksocfortressbeta_on_update_hook_enabled",
        "param_human_name": "Triggers automatically on IOC update",
        "param_description": "Set to True to automatically add a asksocfortressbeta insight each time an IOC is updated",
        "default": False,
        "mandatory": True,
        "type": "bool",
        "section": "Triggers"
    },
    {
        "param_name": "asksocfortressbeta_report_as_attribute",
        "param_human_name": "Add asksocfortressbeta report as new IOC attribute",
        "param_description": "Creates a new attribute on the IOC, base on the asksocfortressbeta report. Attributes are based "
                             "on the templates of this configuration",
        "default": True,
        "mandatory": True,
        "type": "bool",
        "section": "Insights"
    },# TODO: careful here, remove backslashes from \{\{ results| tojson(indent=4) \}\}
    {
        "param_name": "asksocfortressbeta_report_template",
        "param_human_name": "ASK SOCFortress report template",
        "param_description": "ASK SOCFortress report template used to add a new custom attribute to the target IOC",
        "default": "<div class=\"row\">\n    <div class=\"col-12\">\n<style>img { display: block; margin: 0 auto;}</style><img src=\"PATH_TO_LOGO\">\n  {% for section_title in report %}<h2>{{ section_title }}</h2>\n {% for line in report[section_title] %} <p>{{ line }}</p> {% endfor %} {% endfor %}\n\n</div></div>",
        "mandatory": True,
        "type": "textfield_html",
        "section": "Templates"
    },
    {
        "param_name": "asksocfortressbeta_error_report_template",
        "param_human_name": "SOCFortress Says error report template",
        "param_description": "SOCFortress Says error report template used to add a new custom attribute to the target IOC",
        "default": "<div class=\"row\">\n    <div class=\"col-12\">\n<style>img { display: block; margin: 0 auto;}</style><img src=\"PATH_TO_LOGO\">\n  {% for error in report %}<h2>{{ error }}</h2>\n {% for line in report[error] %} <p>{{ line }}</p> {% endfor %} {% endfor %}\n\n</div></div>",
        "mandatory": True,
        "type": "textfield_html",
        "section": "Templates"
    }
    
]
