#!/usr/bin/env python3
#
#
#  IRIS asksocfortressbeta Source Code
#  Copyright (C) 2023 - socfortress
#  info@socfortress.co
#  Created by socfortress - 2023-02-14
#
#  License MIT

import json
import requests
import traceback
from jinja2 import Template

import iris_interface.IrisInterfaceStatus as InterfaceStatus
from app.datamgmt.manage.manage_attribute_db import add_tab_attribute_field


class AsksocfortressbetaHandler(object):
    def __init__(self, mod_config, server_config, logger):
        self.mod_config = mod_config
        self.server_config = server_config
        self.asksocfortressbeta = self.get_asksocfortressbeta_instance()
        self.log = logger

    def get_asksocfortressbeta_instance(self):
        """
        Returns an asksocfortressbeta API instance depending if the key is premium or not

        :return: { cookiecutter.keyword }} Instance
        """
        url = self.mod_config.get('asksocfortressbeta_url')
        key = self.mod_config.get('asksocfortressbeta_key')
        proxies = {}

        if self.server_config.get('http_proxy'):
            proxies['https'] = self.server_config.get('HTTPS_PROXY')

        if self.server_config.get('https_proxy'):
            proxies['http'] = self.server_config.get('HTTP_PROXY')

        # TODO!
        # Here get your asksocfortressbeta instance and return it
        # ex: return asksocfortressbetaApi(url, key)
        return "<TODO>"

    def gen_error_report_from_template(self, html_template, report) -> InterfaceStatus:
        """
        Generates an HTML report for IOC, displayed as an attribute in the IOC
        :param html_template: A string representing the HTML template
        :param misp_report: The JSON report fetched with socfortressmodulepoc API
        :return: InterfaceStatus
        """
        template = Template(html_template)
        for error in report:

            if len(report[error]) <= 2: 
                return InterfaceStatus.I2Error(data="Invalid input data")
            if report[error].startswith('"'):
                report[error] = report[error][1:]
            if report[error].endswith('"'):
                report[error] = report[error][:-1]

            report[error] = report[error].replace("\\n\\n", '\n')
            report[error] = report[error].replace("\\r\\n\\r\\n", "\n")
            report[error] = report[error].replace("\\r\\n", "\n")
            report[error] = report[error].replace("\\", "")

            temp_split = report[error].split('\n')
            if len(temp_split) > 1:
                report[error] = temp_split[1:]
            else:
                report[error] = temp_split

        try:
            rendered = template.render({"report": report})

        except Exception:
            print(traceback.format_exc())
            self.log.error(traceback.format_exc())
            return InterfaceStatus.I2Error(traceback.format_exc())

        return InterfaceStatus.I2Success(data=rendered)
    
    def gen_report_from_template(self, html_template, report) -> InterfaceStatus:
        """
        Generates an HTML report for IOC, displayed as an attribute in the IOC
        :param html_template: A string representing the HTML template
        :param misp_report: The JSON report fetched with socfortressmodulepoc API
        :return: InterfaceStatus
        """
        template = Template(html_template)
        for section_title in report:

            if len(report[section_title]) <= 2: 
                return InterfaceStatus.I2Error(data="Invalid input data")
            if report[section_title].startswith('"'):
                report[section_title] = report[section_title][1:]
            if report[section_title].endswith('"'):
                report[section_title] = report[section_title][:-1]

            report[section_title] = report[section_title].replace("\\n\\n", '\n')
            report[section_title] = report[section_title].replace("\\r\\n\\r\\n", "\n")
            report[section_title] = report[section_title].replace("\\r\\n", "\n")
            report[section_title] = report[section_title].replace("\\", "")

            temp_split = report[section_title].split('\n')
            if len(temp_split) > 1:
                report[section_title] = temp_split[1:]
            else:
                report[section_title] = temp_split

        try:
            rendered = template.render({"report": report})

        except Exception:
            print(traceback.format_exc())
            self.log.error(traceback.format_exc())
            return InterfaceStatus.I2Error(traceback.format_exc())

        return InterfaceStatus.I2Success(data=rendered)

    def status_check(self):
        """
        Checks the status of SOCFortress Knowledge Base
        :return: InterfaceStatus
        """
        # Submit To SOCFortress Knowledge Base
        headers = {'Content-Type': 'application/json'}
        url = 'https://api.socfortress.co/status'
        self.log.info(f'Checking SOCFortress Knowledge Base status')
        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            response_json = response.json()
            status = response_json.get('status')
            self.log.error(f'Status: {status}')
            return InterfaceStatus.I2Error(data=f'Status Code: {response.status_code}') 
        else:
            self.log.info(f'Status Code: {response.status_code}')
            return True
    
    def handle_domain(self, ioc):
        """
        Handles an IOC of type domain and submits to ASK SOCFortress Knowledge Base

        :param ioc: IOC instance
        :return: IIStatus
        """

        self.log.info(f'Getting domain report for {ioc.ioc_value}')

        knowledge_base = self.mod_config.get("knowledgebase_url")
        api_key = self.mod_config.get("api_key")
        firewall = self.mod_config.get("firewall")

        # Submit To SOCFortress Knowledge Base
        headers = {'Content-Type': 'application/json', 'x-api-key': api_key, 'module-version': '1.0'}
        payload = {"attribute_type":"domain", "vendor": firewall}
        response = requests.post(knowledge_base, data=json.dumps(payload), headers=headers)
        self.log.info(f'Status Code: {response.status_code}')
        if response.status_code == 200:
            self.log.info(f'Received response from SOCFortress Knowledge Base')
            r_json = response.json()
            procedure = r_json.get('procedure')
            technical = r_json.get('technical')
            procedure_id = r_json.get('procedure_id')
            technical_id = r_json.get('technical_id')

        # Failure Report
        if response.status_code != 200:
            r_json = response.json()
            error = r_json.get('error')
            self.log.error(f'Error submitting to SOCFortress Knowledge Base: {error}')
            report = {
                "Error": error
            }
            status = self.gen_error_report_from_template(self.mod_config.get('asksocfortressbeta_error_report_template'), report)
            if not status.is_success():
                return status

            rendered_report = status.get_data()

            try:
                add_tab_attribute_field(ioc, tab_name='ASK SOCFortress Error', field_name="HTML report", field_type="html",
                                        field_value=rendered_report)

            except Exception:

                self.log.error(traceback.format_exc())
                return InterfaceStatus.I2Error(traceback.format_exc())

            return InterfaceStatus.I2Success()

        # Success Report
        if self.mod_config.get('asksocfortressbeta_report_as_attribute') is True:
            self.log.info('Adding new attribute Report to IOC')

            report = {
                "Procedure": procedure,
                "Technical": technical,
                "Procedure ID": procedure_id,
                "Technical ID": technical_id
            }

            status = self.gen_report_from_template(self.mod_config.get('asksocfortressbeta_report_template'), report)

            if not status.is_success():
                return status

            rendered_report = status.get_data()

            try:
                add_tab_attribute_field(ioc, tab_name='ASK SOCFortress Report', field_name="HTML report", field_type="html",
                                        field_value=rendered_report)

            except Exception:

                self.log.error(traceback.format_exc())
                return InterfaceStatus.I2Error(traceback.format_exc())
        else:
            self.log.info('Skipped adding attribute report. Option disabled')

        return InterfaceStatus.I2Success()

    def handle_ip(self, ioc):
        """
        Handles an IOC of type IP and submits to ASK SOCFortress Knowledge Base

        :param ioc: IOC instance
        :return: IIStatus
        """

        self.log.info(f'Getting IP report for {ioc.ioc_value}')

        knowledge_base = self.mod_config.get("knowledgebase_url")
        api_key = self.mod_config.get("api_key")
        firewall = self.mod_config.get("firewall")

        # Submit To SOCFortress Knowledge Base
        headers = {'Content-Type': 'application/json', 'x-api-key': api_key, 'module-version': '1.0'}
        payload = {"attribute_type":"ip", "vendor": firewall}
        response = requests.post(knowledge_base, data=json.dumps(payload), headers=headers)
        self.log.info(f'Status Code: {response.status_code}')
        if response.status_code == 200:
            self.log.info(f'Received response from SOCFortress Knowledge Base')
            r_json = response.json()
            procedure = r_json.get('procedure')
            technical = r_json.get('technical')
            procedure_id = r_json.get('procedure_id')
            technical_id = r_json.get('technical_id')

        # Failure Report
        if response.status_code != 200:
            r_json = response.json()
            error = r_json.get('error')
            self.log.error(f'Error submitting to SOCFortress Knowledge Base: {error}')
            report = {
                "Error": error
            }
            status = self.gen_error_report_from_template(self.mod_config.get('asksocfortressbeta_error_report_template'), report)
            if not status.is_success():
                return status

            rendered_report = status.get_data()

            try:
                add_tab_attribute_field(ioc, tab_name='ASK SOCFortress Error', field_name="HTML report", field_type="html",
                                        field_value=rendered_report)

            except Exception:

                self.log.error(traceback.format_exc())
                return InterfaceStatus.I2Error(traceback.format_exc())

            return InterfaceStatus.I2Success()

        # Success Report
        if self.mod_config.get('asksocfortressbeta_report_as_attribute') is True:
            self.log.info('Adding new attribute Report to IOC')

            report = {
                "Procedure": procedure,
                "Technical": technical,
                "Procedure ID": procedure_id,
                "Technical ID": technical_id
            }

            status = self.gen_report_from_template(self.mod_config.get('asksocfortressbeta_report_template'), report)

            if not status.is_success():
                return status

            rendered_report = status.get_data()

            try:
                add_tab_attribute_field(ioc, tab_name='ASK SOCFortress Report', field_name="HTML report", field_type="html",
                                        field_value=rendered_report)

            except Exception:

                self.log.error(traceback.format_exc())
                return InterfaceStatus.I2Error(traceback.format_exc())
        else:
            self.log.info('Skipped adding attribute report. Option disabled')

        return InterfaceStatus.I2Success()

    def handle_hash(self, ioc):
        """
        Handles an IOC of type hash and submits to ASK SOCFortress Knowledge Base

        :param ioc: IOC instance
        :return: IIStatus
        """

        self.log.info(f'Getting hash report for {ioc.ioc_value}')

        knowledge_base = self.mod_config.get("knowledgebase_url")
        api_key = self.mod_config.get("api_key")
        firewall = self.mod_config.get("firewall")

        # Submit To SOCFortress Knowledge Base
        headers = {'Content-Type': 'application/json', 'x-api-key': api_key, 'module-version': '1.0'}
        payload = {"attribute_type":"hash", "vendor": firewall}
        response = requests.post(knowledge_base, data=json.dumps(payload), headers=headers)
        self.log.info(f'Status Code: {response.status_code}')
        if response.status_code == 200:
            self.log.info(f'Received response from SOCFortress Knowledge Base')
            r_json = response.json()
            procedure = r_json.get('procedure')
            technical = r_json.get('technical')
            procedure_id = r_json.get('procedure_id')
            technical_id = r_json.get('technical_id')

        # Failure Report
        if response.status_code != 200:
            r_json = response.json()
            error = r_json.get('error')
            self.log.error(f'Error submitting to SOCFortress Knowledge Base: {error}')
            report = {
                "Error": error
            }
            status = self.gen_error_report_from_template(self.mod_config.get('asksocfortressbeta_error_report_template'), report)
            if not status.is_success():
                return status

            rendered_report = status.get_data()

            try:
                add_tab_attribute_field(ioc, tab_name='ASK SOCFortress Error', field_name="HTML report", field_type="html",
                                        field_value=rendered_report)

            except Exception:

                self.log.error(traceback.format_exc())
                return InterfaceStatus.I2Error(traceback.format_exc())

            return InterfaceStatus.I2Success()

        # Success Report
        if self.mod_config.get('asksocfortressbeta_report_as_attribute') is True:
            self.log.info('Adding new attribute Report to IOC')

            report = {
                "Procedure": procedure,
                "Technical": technical,
                "Procedure ID": procedure_id,
                "Technical ID": technical_id
            }

            status = self.gen_report_from_template(self.mod_config.get('asksocfortressbeta_report_template'), report)

            if not status.is_success():
                return status

            rendered_report = status.get_data()

            try:
                add_tab_attribute_field(ioc, tab_name='ASK SOCFortress Report', field_name="HTML report", field_type="html",
                                        field_value=rendered_report)

            except Exception:

                self.log.error(traceback.format_exc())
                return InterfaceStatus.I2Error(traceback.format_exc())
        else:
            self.log.info('Skipped adding attribute report. Option disabled')

        return InterfaceStatus.I2Success()
